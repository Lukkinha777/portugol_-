programa
{
	funcao inicio()
	{

		inteiro numero
		inteiro total_digitados
		
		
		total_digitados = 0

		escreva("Digite um número (ou um negativo para sair): ")
		leia(numero)

	
		enquanto (numero >= 0)
		{

			total_digitados = total_digitados + 1
			
	
			escreva("Digite o próximo número (ou um negativo para sair): ")
			leia(numero)
		}

	
		escreva("\nO total de números digitados (antes do negativo) foi: ", total_digitados)
	}
}
