programa {
  inteiro n1
  funcao inicio() {
    escreva ("me fale um numero: ")
    leia (n1)
    se (n1 > 10){
      escreva ("esse numeor é maior que 10 ")
    }
    senao {
      escreva ("é um numero normal ")
    }
    
  }
}
