programa {
  inteiro n1,n2,n3
  funcao inicio() {
    escreva ("me diga o valor do primeiro numero: ")
    leia (n1)
    escreva ("me diga o valor do segundo numero: ")
    leia (n2)
    escreva ("me diga o valor do terceiro numero: ")
    leia (n3)
    se (n1>n2 e n1>n3)
    escreva (n1)
        senao se (n2>n1 e n2>n3)
    escreva (n2)
        senao{
    escreva (n3)
        }


    }
  }

