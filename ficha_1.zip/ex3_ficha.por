programa {
  inteiro n1
  funcao inicio() {
    escreva ("me diga um numero entre: ")
    leia (n1)
    se (n1 >=100 e n1 <= 200){
      escreva ("este numero esta no intervalo entre 100 a 200")
    }
    senao {
      escreva(" nao esta no intervalo entre 100 a 200")
    }


    
  }
}
