programa {
  inteiro codigo
  funcao inicio() {
    escreva ("codigo do produto: ")
    leia (codigo)
    escolha (codigo){
    caso 100: escreva ("prego")
                pare
    caso 200: escreva ("parafuso")
                pare
    caso 300: escreva ("anilha")
                pare
    caso 400: escreva ("agulha")
                pare
    caso 500: escreva ("tesoura")
                pare
  caso contrario: escreva ("nao existe este produto")
  }

  }
}
